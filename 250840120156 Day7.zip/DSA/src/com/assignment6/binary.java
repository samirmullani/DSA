package com.assignment6;

public class binary {

static class Node
{
int data;
Node left,right;

Node(int data)
{
this.data=data;
left=right=null;
}
}

Node root;

binary() //constructor
{
root=null;
}

/*****PreOrderTraversal(root,left,right)******/
void printusingPreorder()
{
 System.out.print("Preorder: ");
 preorder(root);
 System.out.println();
 
}


private void preorder (Node node)
   {
      if(node==null)
        return;
      System.out.print(node.data+" ");
      preorder(node.left);
      preorder(node.right);
   }


/****PostOrderTraversal(left,right,root)*****/
void printusingPostorder()
{
  System.out.print("Postorder: ");
  Postorder(root);
  System.out.println();
 
}


private void Postorder (Node node)
{
  if(node==null)
    return;
  Postorder (node.left);
  Postorder(node.right);
  System.out.print(node.data+" ");

}


//2.COUNT TOTAL NODES IN TREE

int countnodes()
{
return countnodes(root);

}

private int countnodes(Node node)
{
  if(node==null)
  return 0;
  return 1+countnodes(node.left)+countnodes(node.right);
 
}

//3.COUNT LEAF NODES

int countleafnodes()
{
return countleafnodes(root);

}

private int countleafnodes(Node node)
{
  if(node==null)
  return 0;

  if(node.left==null && node.right==null)
 return 1;
  return countleafnodes(node.left)+countleafnodes(node.right);
}



//4.COUNT NODES WITH SPECIFIC VALUE

int countnodeswithvalue(int value)
{
return countnodeswithvalue(root,value);

}

private int countnodeswithvalue(Node node,int value)
{
if(node==null)
return 0;
int count=(node.data==value)? 1:0;

return count + countnodeswithvalue(node.left,value)+countnodeswithvalue(node.right,value);
}


//helper to insert data
Node insert(Node node,int data)
{
if(node==null)
return new Node(data);

if(data<node.data)
node.left=insert(node.left,data);
else
node.right=insert(node.right,data);
return  node;

}

public static void main(String[]args)
{
  binary tree=new binary();
 
  tree.root=tree.insert(tree.root,10);
  tree.root=tree.insert(tree.root,5);
  tree.root=tree.insert(tree.root,15);

  tree.root=tree.insert(tree.root,7);

  tree.root=tree.insert(tree.root,12);
 
  tree.root=tree.insert(tree.root,3);


  tree.root=tree.insert(tree.root,18);


  //traversal
  tree.printusingPreorder();

  tree.printusingPostorder();
 
 
  //count
  System.out.println("Total Nodes: "+tree.countnodes());
 
  System.out.println("Leaf Nodes: "+tree.countleafnodes());

  System.out.println("Node With Value 3: "+tree.countnodeswithvalue(3));

}

}