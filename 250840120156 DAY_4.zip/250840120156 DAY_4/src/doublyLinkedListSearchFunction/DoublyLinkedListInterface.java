package doublyLinkedListSearchFunction;

public interface DoublyLinkedListInterface {
	
	void addFirst(int data);
	void addLast(int data);
	void addAtIndex(int data, int index);
	void deleteFirst();
	void deleteLast();
	void displayForward();
	void displayBackward();
	boolean search(int element);
	

}
