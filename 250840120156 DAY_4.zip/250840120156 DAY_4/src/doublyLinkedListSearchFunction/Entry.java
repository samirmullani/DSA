package doublyLinkedListSearchFunction;

import java.util.Scanner;

public class Entry {

	public static void main(String[] args) {

		DoublyLinkedListInterface dlli = new DoublyLinkedList();
		dlli.addFirst(10);
		dlli.addLast(20);
		dlli.addAtIndex(15, 1);

		dlli.displayForward();
		dlli.displayBackward();

		dlli.deleteFirst();

		dlli.displayForward();

		dlli.deleteLast();

		dlli.displayForward();

		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter element to search:");
		int element = scanner.nextInt();
		if (dlli.search(element)) {
			System.out.println("Element found in the list.");
		} else {
			System.out.println("Element not found in the list.");
		}
		scanner.close();
	}

}
