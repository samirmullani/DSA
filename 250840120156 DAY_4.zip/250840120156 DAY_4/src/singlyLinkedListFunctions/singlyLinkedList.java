package singlyLinkedListFunctions;

class SinglyLinkedList implements SinglyLinkedListLinkedListInterface {

//	private class Node{
//		int data;
//		Node next;
//	}

	private Node head;
	private Node tail;

	public SinglyLinkedList() {
		head = null;
		tail = null;
	}

	@Override
	public void addAtFront(int element) {
		Node newNode = new Node(element);
//		newNode.data = element;
		newNode.next = head;
		head = newNode;
		if (tail == null) {
			tail = head;
		}
	}

	@Override
	public void addAtEnd(int element) {
		Node newNode = new Node(element);
		newNode.data = element;
		newNode.next = null;
		if (tail == null) {
			head = newNode;
			tail = newNode;
		} else {
			tail.next = newNode;
			tail = newNode;
		}
	}

	@Override
	public void deleteFirstNode() {
		if (isEmpty()) {
			throw new IllegalStateException("List is empty");
		}
//		Node temp = head;
		head = head.next;
		if (head == null) {
			tail = head;
		}
//		return temp.data;
	}

	@Override
	public void deleteEndNode() {
		if (isEmpty()) {
			throw new IllegalStateException("List is empty");
		}
		if (head == tail) {
//			int data = head.data;
			head = null;
			tail = null;
//			return data;
		}
		Node current = head;
		while (current.next != tail) {
			current = current.next;
		}
//		int data = tail.data;
		current.next = null;
		tail = current;
//		return data;
	}

	@Override
	public boolean isEmpty() {
		if (head == null) {
			return true;
		}
		return false;
	}

	@Override
	public void print() {
		if (isEmpty()) {
			System.out.println("List is empty. Cannot display.");
			return;
		}
		Node current = head;
		while (current != null) {
			System.out.println(current.data);
			current = current.next;
		}
	}

	@Override
	public void delete(int element) {
		if (isEmpty()) {
			System.out.println("List is empty. Cannot delete.");
			return;
		}
		if (head.data == element) {
			deleteFirstNode();
			return;
		}
		Node current = head;
		Node previous = null;
		while (current != null && current.data != element) {
			previous = current;
			current = current.next;
		}
		if (current == null) {
			System.out.println("Element not found in the list.");
			return;
		}
		previous.next = current.next;

	}

	@Override
	public void deleteAll(int element) {
		if (isEmpty()) {
			System.out.println("List is empty. Cannot delete.");
			return;
		}
		while (head != null && head.data == element) {
			deleteFirstNode();
		}
		Node current = head;
		Node previous = null;
		while (current != null) {
			if (current.data == element) {
				previous.next = current.next;
				current = current.next;
			} else {
				previous = current;
				current = current.next;
			}
		}
	}

//	@Override
//	public void deleteAll(int) {
//		
//		
//		head = null;
//		tail = null;
//			
//		}

	@Override
	public boolean search(int element) {
		Node current = head;
		while (current != null) {
			if (current.data == element) {
				System.out.println("Element Found");
				return true;
			}

			current = current.next;
		}

		return false;
	}

}
