package singlyLinkedListFunctions;

public class Entry {
	public static void main(String[] args) {
		SinglyLinkedListLinkedListInterface slli = new SinglyLinkedList();
		try {
			slli.addAtFront(10);
			slli.addAtEnd(20);
			slli.addAtFront(30);
			slli.addAtFront(40);

			slli.print();

//	 System.out.println(list.search(15));

			if (slli.search(15) == false) {
				System.out.println("Element Not found");
			} else {
				System.out.println("Element found");
			}
//	 list.deleteAll();

//	 list.print();

			slli.delete(20);

			slli.print();

			slli.deleteFirstNode();

			slli.print();
		} catch (IllegalStateException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}

	}

}
