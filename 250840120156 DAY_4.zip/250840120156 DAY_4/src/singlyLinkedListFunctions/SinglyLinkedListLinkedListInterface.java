package singlyLinkedListFunctions;

public interface SinglyLinkedListLinkedListInterface {
	void addAtFront(int element);
	void addAtEnd(int element);
	void deleteFirstNode();
	void deleteEndNode();
	boolean isEmpty();
	void print();
	void delete(int element);
	void deleteAll(int element);
	boolean search(int element);

}
