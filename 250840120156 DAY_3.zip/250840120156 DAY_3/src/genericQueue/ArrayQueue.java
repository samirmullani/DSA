package genericQueue;

public class ArrayQueue<T> implements QueueInterface<T> {

	private T[] queueArray;
	private int front;
	private int rear;
	private int size;
	private static final int DEFAULT_CAPACITY = 10;

	@SuppressWarnings("unchecked")
	public ArrayQueue() {
		this.queueArray = (T[]) new Object[DEFAULT_CAPACITY];
		this.front = 0;
		this.rear = 0;
		this.size = 0;
	}

	@SuppressWarnings("unchecked")
	private void resize(int capacity) {
		T[] newArray = (T[]) new Object[capacity];
		for (int i = 0; i < size; i++) {
			newArray[i] = queueArray[(front + i) % queueArray.length];

		}
		queueArray = newArray;
		front = 0;
		rear = size;
	}

	@Override
	public void enqueue(T element) {

		if (size == queueArray.length) {
			resize(2 * queueArray.length);
		}

		queueArray[rear] = element;

		rear = (rear + 1) % queueArray.length;
		size++;
	}

	@Override
	public T dequeue() throws EmptyQueueException {
		if (isEmpty()) {
			throw new EmptyQueueException("Cannot dequeue from an empty queue (Queue Underflow).");
		}

		T element = queueArray[front];
		queueArray[front] = null;

		front = (front + 1) % queueArray.length;
		size--;

		if (size > 0 && size == queueArray.length / 4) {

			resize(Math.max(DEFAULT_CAPACITY, queueArray.length / 2));
		}

		return element;
	}

	@Override
	public T peek() throws EmptyQueueException {
		if (isEmpty()) {
			throw new EmptyQueueException("Cannot peek at an empty queue.");
		}
		return queueArray[front];
	}

	@Override
	public boolean isEmpty() {
		return size == 0;
	}
}
