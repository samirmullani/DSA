package genericQueue;

public class LinkedListQueue<T> implements QueueInterface<T> {

	// Inner class representing a node in the linked list
	private static class Node<T> {
		T data;
		Node<T> next;

		public Node(T data) {
			this.data = data;
			this.next = null;
		}
	}

	private Node<T> head; 
	private Node<T> tail; 
	private int size;

	public LinkedListQueue() {
		this.head = null;
		this.tail = null;
		this.size = 0;
	}

	public void enqueue(T element) {
		Node<T> newNode = new Node<>(element);

		if (isEmpty()) {

			head = newNode;
		} else {

			tail.next = newNode;
		}
		// Update the tail pointer to the new node
		tail = newNode;
		size++;
	}

	public T dequeue() throws EmptyQueueException {
		if (isEmpty()) {
			throw new EmptyQueueException("Cannot dequeue from an empty queue (Queue Underflow).");
		}

		T data = head.data;
		// Move the head pointer to the next node
		head = head.next;
		size--;


		if (head == null) {
			tail = null;
		}

		return data;
	}

	@Override
	public T peek() throws EmptyQueueException {
		if (isEmpty()) {
			throw new EmptyQueueException("Cannot peek at an empty queue.");
		}
		return head.data;
	}


	@Override
	public boolean isEmpty() {
		return head == null; // Equivalently: return size == 0;
	}

	public int size() {
		return size;
	}

}
