package genericQueue;

public class EntryArrayQueue {

	public static void main(String[] args) {
		QueueInterface<Integer> queue = new ArrayQueue<>();

		try {
			queue.enqueue(10);
			queue.enqueue(20);
			queue.enqueue(30);

			System.out.println("Dequeued: " + queue.dequeue());
			System.out.println("Peek: " + queue.peek());

			queue.enqueue(40);
			System.out.println("Dequeued: " + queue.dequeue());
			System.out.println("Dequeued: " + queue.dequeue());
			System.out.println("Dequeued: " + queue.dequeue());

			System.out.println("Dequeued: " + queue.dequeue());
		} catch (EmptyQueueException e) {
			System.err.println(e.getMessage());
		}

	}

}
