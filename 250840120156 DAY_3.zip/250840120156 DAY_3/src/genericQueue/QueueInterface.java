package genericQueue;

public interface QueueInterface<T> {
	void enqueue(T element);

	 T dequeue() throws EmptyQueueException;
	
	T peek() throws EmptyQueueException;

	boolean isEmpty();
	
	
	
}
