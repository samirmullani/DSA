package genericStack;

public class Entry {

	public static void main(String[] args) {
		ResizableArrayStack<Integer> stack = new ResizableArrayStack<>();
		try {
			stack.push(10);
			stack.push(20);
			stack.push(30);
			System.out.println("Popped element: " + stack.pop());
			System.out.println("Popped element: " + stack.pop());
			System.out.println("Popped element: " + stack.pop());
			// This will throw an exception
			System.out.println("Popped element: " + stack.pop());
		} catch (CustomException e) {
			System.err.println("Error: " + e.getMessage());
		}
	

	}

}
