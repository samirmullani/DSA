package genericStack;

public class ResizableArrayStack<E> implements StackInterface<E> {

	private E[] stackArray;
	private int top;
	private static final int DEFAULT_CAPACITY = 10;

	@SuppressWarnings("unchecked")
	public ResizableArrayStack() {
		this.stackArray = (E[]) new Object[DEFAULT_CAPACITY];
		this.top = 0;
	}


	// --- Stack Interface Methods ---

	@Override
	public void push(E element) {
		// Check if the current capacity is exhausted
		if (top == stackArray.length) {
			resize(2 * stackArray.length); // Double the array size
		}
		stackArray[top] = element;
		top++;
	}

	@Override
	public E pop() throws CustomException {
		if (isEmpty()) {
			// Throw the required CustomException
			throw new CustomException("Cannot pop from an empty stack (Stack Underflow).");
		}
		top--;
		E element = stackArray[top];
		stackArray[top] = null; 

		if (top > 0 && top == stackArray.length / 4) {
			// Ensure the array size doesn't drop below default capacity
			resize(Math.max(DEFAULT_CAPACITY, stackArray.length / 2));
		}

		return element;
	}

	@Override
	public E peek() throws CustomException {
		if (isEmpty()) {
			throw new CustomException("Cannot peek at an empty stack.");
		}
		// The top element is always at index top - 1
		return stackArray[top - 1];
	}

	@Override
	public boolean isEmpty() {
		return top == 0;
	}

	@Override
	public boolean isFull() {
		return false;
	}

	@SuppressWarnings("unchecked")
	private void resize(int capacity) {
		E[] newArray = (E[]) new Object[capacity];
		
		System.arraycopy(stackArray, 0, newArray, 0, top);

		this.stackArray = newArray;
	}

	public int size() {
		return top;
	}

}
