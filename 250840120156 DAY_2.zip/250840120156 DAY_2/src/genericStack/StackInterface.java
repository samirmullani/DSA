package genericStack;


public interface StackInterface<T> {

	void push(T element);
	
	T pop() throws CustomException;

    T peek() throws CustomException;

    boolean isEmpty();

    boolean isFull();
    
    int size();

    
}
