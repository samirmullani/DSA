//1. Write recursive algorithm to find quotient after dividing two numbers. Using above definition, implement following function to return quotient after dividing two numbers (a / b).
//Follow up: Modify implementation/Implement wrapper function to handle both positive and negative numbers.

package recurssion.Question_1;

public class Entry {

	static int quotient(int a, int b) throws Exception {

		if (b == 0)
			throw new Exception("Cannot Divide by Zero.");
		// For Negative Number
		if (a < 0) {
			if (-(a) < b)
				return 0;

			return -1 + quotient(a + b, b);
		}
		// For Positive Number
		else {
			if (a < 0)
				return 0;

			if (a < b)
				return 0;

			return 1 + quotient(a - b, b);
		}

	}

	public static void main(String[] args) {

		try {
			System.out.println("Quotient:- " + quotient(-6, 2));
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

}
