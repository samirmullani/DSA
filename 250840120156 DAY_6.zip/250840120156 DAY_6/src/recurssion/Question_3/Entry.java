//3. Implement following funtion to "optimally" multiple two numbers, recursively. Handle both negative and positive numbers.

package recurssion.Question_3;

public class Entry {

	static int multiply(int a, int b) {

		if (a == 0)
			return 0;

		if (b == 0)
			return 0;

		return a + multiply(a, b - 1);

	}

	public static void main(String[] args) {

		System.out.println(multiply(-1, 8));
	}

}
