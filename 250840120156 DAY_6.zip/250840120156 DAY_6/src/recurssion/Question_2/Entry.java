//2. Write recursive algorithm to find remainder after dividing two numbers.
// Using above definition, implement following function to return remainder after dividing two numbers (a % b).

package recurssion.Question_2;

public class Entry {

	// Follow up: Modify implementation/Implement wrapper function to handle both
	// positive and negative numbers.
	static int remainder(int a, int b) throws Exception {
		if (b == 0)
			throw new Exception("Cannot Divide by Zero.");

//		if(a<0)
//			return 0;
		// For Negative number
		if (a < 0) {
			if (-(a) < b)
				return a;

			return remainder(a + b, b);
		}
		// For Positive Number
		else {
			if (a < b)
				return a;

			return remainder(a - b, b);
		}

	}

	public static void main(String[] args) {

		try {
			System.out.println("Remiander: " + remainder(-7, 2));
		} catch (Exception e) {
			e.getMessage();
		}
	}

}
