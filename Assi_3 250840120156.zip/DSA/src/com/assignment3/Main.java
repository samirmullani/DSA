package com.assignment3;

class Node {
    int data;
    Node next;
    Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class SinglyLinkedList {
    Node head;

    // Delete first occurrence of specified element
    
    void delete(int element) {
        if (head == null) return; 

        if (head.data == element) {
            head = head.next;
            return;
        }

        Node curr = head;
        while (curr.next != null && curr.next.data != element) {
            curr = curr.next;
        }

        if (curr.next != null) {
            curr.next = curr.next.next; 
        }
    }

    // Delete all occurrences of specified element
    
    void deleteAll(int element) 
  {
      while (head != null && head.data == element)
    {
         head = head.next;
   }

   Node curr = head;
  while (curr != null && curr.next != null) {
   if (curr.next.data == element)
   {
      curr.next = curr.next.next;
         
   } 
     else
         {
             curr = curr.next;
           }
        }
    }

    // Search for element
    boolean search(int element)
    {
        Node curr = head;
        while (curr != null)
        {
            if (curr.data == element)
                return true;
            curr = curr.next;
        }
        return false;
    }

    // Utility(helper function) to print the list
    
    void printList() {
        Node curr = head;
        while (curr != null)
        {
            System.out.print(curr.data + " -> ");
            curr = curr.next;
        }
        System.out.println("null");
    }

    // Utility to insert at end 
    
    void insert(int data)
    {
        Node newNode = new Node(data);
        if (head == null) 
        {
            head = newNode;
            return;
        }
        Node curr = head;
        while (curr.next != null)
        curr = curr.next;
        curr.next = newNode;
    }
}

public class Main {
    public static void main(String[] args) {
        SinglyLinkedList list = new SinglyLinkedList();
        list.insert(10);
        list.insert(20);
        list.insert(30);
        list.insert(20);
        list.insert(40);
        list.printList();

        System.out.println("Search 30: " + list.search(30));
        list.delete(20);
        list.printList();

        list.deleteAll(20);
        list.printList();
    }
}

