package com.assignment3;

class DNode {
    int data;
    DNode prev, next;
    DNode(int data) {
        this.data = data;
    }
}

class DoublyLinkedList {
    DNode head;

    // Insert at end
    void insert(int data) {
        DNode newNode = new DNode(data);
        if (head == null) {
            head = newNode;
            return;
        }
        DNode curr = head;
        while (curr.next != null)
            curr = curr.next;
        curr.next = newNode;
        newNode.prev = curr;
    }

    // Search element
    boolean search(int element) {
        DNode curr = head;
        while (curr != null) {
            if (curr.data == element)
                return true;
            curr = curr.next;
        }
        return false;
    }

    // Print list
    void printList() {
        DNode curr = head;
        while (curr != null) {
            System.out.print(curr.data + " <-> ");
            curr = curr.next;
        }
        System.out.println("null");
    }
}

public class Main2 {
    public static void main(String[] args) {
        DoublyLinkedList list = new DoublyLinkedList();
        list.insert(5);
        list.insert(10);
        list.insert(15);
        list.printList();

        System.out.println("Search 10: " + list.search(10));
        System.out.println("Search 50: " + list.search(50));
    }
}
