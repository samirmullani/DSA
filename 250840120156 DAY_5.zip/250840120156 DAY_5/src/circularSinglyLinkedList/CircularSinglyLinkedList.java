package circularSinglyLinkedList;

class CircularSinglyLinkedList implements CircularSinglyLinkedListInterface {
	private class Node {
		int data;
		Node next;

		Node(int data) {
			this.data = data;
		}
	}

	private Node head;
	private Node tail;

	public CircularSinglyLinkedList() {
        head = null;
        tail = null;
    }

	
	// Add at Front

	@Override
	public void addAtFront(int element) {
		Node newNode = new Node(element);
		if (head == null) {
			head = newNode;
			tail = newNode;
			newNode.next = head; // circular link
		} else {
			newNode.next = head;
			head = newNode;
			tail.next = head; // maintain circular link
		}
	}


	// Add at End

	@Override
	public void addAtEnd(int element) {
		Node newNode = new Node(element);
		if (tail == null) {
			head = newNode;
			tail = newNode;
			newNode.next = head; // circular link
		} else {
			tail.next = newNode;
			tail = newNode;
			tail.next = head; // maintain circular link
		}
	}


	// Delete First Node

	@Override
	public void deleteFirstNode() {
		if (isEmpty()) {
			throw new IllegalStateException("List is empty");
		}

		if (head == tail) { // only one node
			head = null;
			tail = null;
		} else {
			head = head.next;
			tail.next = head; // maintain circular link
		}
	}


	// Delete Last Node

	@Override
	public void deleteEndNode() {
		if (isEmpty()) {
			throw new IllegalStateException("List is empty");
		}

		if (head == tail) { // only one node
			head = null;
			tail = null;
			return;
		}

		Node current = head;
		while (current.next != tail) {
			current = current.next;
		}

		current.next = head; // new tail points to head
		tail = current;
	}


	// Delete Specific Element

	@Override
	public void delete(int element) {
		if (isEmpty()) {
			System.out.println("List is empty. Cannot delete.");
			return;
		}

		Node current = head;
		Node previous = tail; // important for circular traversal

		// Traverse until we reach back to head
		do {
			if (current.data == element) {
				if (current == head) {
					deleteFirstNode();
				} else if (current == tail) {
					deleteEndNode();
				} else {
					previous.next = current.next;
				}
				return;
			}
			previous = current;
			current = current.next;
		} while (current != head);

		System.out.println("Element not found in the list.");
	}

	
	// Delete All Occurrences
	
	@Override
	public void deleteAll(int element) {
		if (isEmpty()) {
			System.out.println("List is empty. Cannot delete.");
			return;
		}

		boolean deleted = false;

		// Handle head nodes first (if multiple match)
		while (head != null && head.data == element) {
			deleteFirstNode();
			deleted = true;
			if (head == null)
				return; // list became empty
		}

		Node current = head;
		Node previous = tail;

		do {
			if (current.data == element) {
				previous.next = current.next;
				if (current == tail)
					tail = previous;
				current = current.next;
				deleted = true;
			} else {
				previous = current;
				current = current.next;
			}
		} while (current != head);

		if (!deleted)
			System.out.println("Element not found in the list.");
	}

	
	// Search
	
	@Override
	public boolean search(int element) {
		if (isEmpty())
			return false;

		Node current = head;
		do {
			if (current.data == element) {
				System.out.println("Element found");
				return true;
			}
			current = current.next;
		} while (current != head);

		System.out.println("Element not found");
		return false;
	}

	
	// Print List
	
	@Override
	public void print() {
		if (isEmpty()) {
			System.out.println("List is empty. Cannot display.");
			return;
		}

		Node current = head;
		do {
			System.out.print(current.data + " ");
			current = current.next;
		} while (current != head);
		System.out.println();
	}

	
	// Utility
	
	@Override
	public boolean isEmpty() {
		return head == null;
	}
}
