package circularSinglyLinkedList;

import java.util.Scanner;

public class Entry {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        CircularSinglyLinkedList list = new CircularSinglyLinkedList();

        int choice;
        do {
            System.out.println("\n===== CIRCULAR SINGLY LINKED LIST MENU =====");
            System.out.println("1. Add at Front");
            System.out.println("2. Add at End");
            System.out.println("3. Delete First Node");
            System.out.println("4. Delete Last Node");
            System.out.println("5. Delete Specific Element");
            System.out.println("6. Delete All Occurrences");
            System.out.println("7. Search Element");
            System.out.println("8. Display List");
            System.out.println("9. Check if List is Empty");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter element to add at front: ");
                    int frontData = sc.nextInt();
                    list.addAtFront(frontData);
                    System.out.println("Added " + frontData + " at front.");
                    break;

                case 2:
                    System.out.print("Enter element to add at end: ");
                    int endData = sc.nextInt();
                    list.addAtEnd(endData);
                    System.out.println("Added " + endData + " at end.");
                    break;

                case 3:
                    try {
                        list.deleteFirstNode();
                        System.out.println("First node deleted.");
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;

                case 4:
                    try {
                        list.deleteEndNode();
                        System.out.println("Last node deleted.");
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;

                case 5:
                    System.out.print("Enter element to delete: ");
                    int delElement = sc.nextInt();
                    list.delete(delElement);
                    break;

                case 6:
                    System.out.print("Enter element to delete all occurrences: ");
                    int delAllElement = sc.nextInt();
                    list.deleteAll(delAllElement);
                    break;

                case 7:
                    System.out.print("Enter element to search: ");
                    int searchElement = sc.nextInt();
                    boolean found = list.search(searchElement);
                    if (!found) System.out.println("Element not found.");
                    break;

                case 8:
                    System.out.println("List elements are: ");
                    list.print();
                    break;

                case 9:
                    if (list.isEmpty())
                        System.out.println("List is empty.");
                    else
                        System.out.println("List is not empty.");
                    break;

                case 0:
                    System.out.println("Exiting... Goodbye!");
                    break;

                default:
                    System.out.println("Invalid choice! Please try again.");
            }

        } while (choice != 0);

        sc.close();
    }
}
