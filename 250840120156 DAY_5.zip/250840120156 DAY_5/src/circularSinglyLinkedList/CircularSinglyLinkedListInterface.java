package circularSinglyLinkedList;

public interface CircularSinglyLinkedListInterface {
	


	void addAtFront(int element);

	void addAtEnd(int element);

	void deleteFirstNode();

	void deleteEndNode();

	void delete(int element);

	void deleteAll(int element);

	boolean search(int element);

	void print();

	boolean isEmpty();

}
