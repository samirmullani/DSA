package doublyLinkedListWithDeleteDeleteAllFunctions;

public class Entry {

	public static void main(String[] args) {
		DoublyLinkedList dll = new DoublyLinkedList();
		
		dll.addLast(10);
		dll.addLast(20);
		dll.addLast(30);
		dll.addLast(20);
		dll.addLast(40);
		dll.addLast(20);
		
		System.out.println("Original List (Forward):");
		dll.displayForward();
		
		System.out.println("Original List (Backward):");
		dll.displayBackward();
		
		dll.deleteAll(20);
		
		System.out.println("List after deleting all occurrences of 20 (Forward):");
		dll.displayForward();
		
		System.out.println("List after deleting all occurrences of 20 (Backward):");
		dll.displayBackward();
		
		dll.delete(30);
		
		System.out.println("List after deleting first occurrence of 30 (Forward):");
		dll.displayForward();
		
		
		
	}

}
