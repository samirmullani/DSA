package doublyLinkedListWithDeleteDeleteAllFunctions;

public interface DoublyLinkedListInterface {
	
	void addFirst(int data);
	void addLast(int data);
	void addAtIndex(int data, int index);
	void deleteFirst();
	void deleteLast();
	void deleteAtIndex(int index);
	void delete(int element);
	void deleteAll(int element);
	void displayForward();
	void displayBackward();
	boolean search(int element);
	

}
