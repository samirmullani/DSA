package com.assignment8;


public class ArrayOperations 
{

    // 1. Linear Search
    boolean findUsingLinearSearch(int[] arr, int element) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == element)
                return true; 
        }
        return false; 
    }

    // 2. Binary Search 
    boolean findUsingBinarySearch(int[] arr, int element) {
        bubbleSort(arr);

        int left = 0;
        int right = arr.length - 1;

        while (left <= right) {
            int mid = (left + right) / 2;

            if (arr[mid] == element)
                return true;

            if (arr[mid] < element)
                right = mid - 1;
            else
                left = mid + 1;
        }
        return false;
    }

    // 3. Bubble Sort in descending order
    void bubbleSort(int[] arr) {
        int n = arr.length;
        boolean swapped;

for (int i = 0; i < n - 1; i++) {
    swapped = false;
    for (int j = 0; j < n - i - 1; j++)
    {
        if (arr[j] < arr[j + 1])
        {
            int temp = arr[j];
            arr[j] = arr[j + 1];
            arr[j + 1] = temp;
            swapped = true;
        }
    }
            if (!swapped)
                break; 
        }
    }

    // 4. Insertion Sort in descending order
    void insertionSort(int[] arr) 
    {
        int n = arr.length;

        for (int i = 1; i < n; i++)
        {
            int key = arr[i];
            int j = i - 1;

            while (j >= 0 && arr[j] < key) 
            {
                arr[j + 1] = arr[j];
                j--;
            }
            arr[j + 1] = key;
        }
    }

    boolean isArraySorted(int[] arr)
    {
        for (int i = 0; i < arr.length - 1; i++)
        {
            if (arr[i] < arr[i + 1])
                return false;
        }
        return true;
    }

    public static void main(String[] args) 
    {
        ArrayOperations obj = new ArrayOperations();
        int[] arr = { 5, 2, 9, 1, 7 };

        System.out.println("Linear Search (9): " + obj.findUsingLinearSearch(arr, 9));
        System.out.println("Linear Search (3): " + obj.findUsingLinearSearch(arr, 3));

        System.out.println("Before Sorting:");
        for (int x : arr)
            System.out.print(x + " ");

        obj.bubbleSort(arr);
        System.out.println("\nAfter Bubble Sort (Descending):");
        for (int x : arr)
            System.out.print(x + " ");

        System.out.println("\nIs Array Sorted: " + obj.isArraySorted(arr));

        System.out.println("\nBinary Search (9): " + obj.findUsingBinarySearch(arr, 9));
        System.out.println("Binary Search (4): " + obj.findUsingBinarySearch(arr, 4));
    }
}
