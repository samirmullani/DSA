package com.assignment1;

public class ArrayDelete {

  int deletefromposition(int[] arr, int n, int pos)
  {
     if (pos < 1 || pos > n) 
     {
      System.out.println("Invalid position!");
       return n; 
  }
    
 for (int i = pos - 1; i < n - 1; i++)
   {
     arr[i] = arr[i + 1];
	 
    }
   
     n = n - 1;
   return n; 
  
	    }

// Test function
public static void main(String[] args) {
    ArrayDelete obj = new ArrayDelete();

    int[] arr = {10, 20, 30, 40, 50};
    int n = 5; // current logical size

    System.out.println("Original array:");
    for (int i = 0; i < n; i++)
        System.out.print(arr[i] + " ");

    int pos = 3; 
    n = obj.deletefromposition(arr, n, pos);

    System.out.println("\nAfter deleting element at position " + pos + ":");
    for (int i = 0; i < n; i++)
        System.out.print(arr[i] + " ");

    System.out.println("\nUpdated logical size: " + n);
}	
 
}

